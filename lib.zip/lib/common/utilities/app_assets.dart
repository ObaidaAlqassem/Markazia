class AppAssets {
  // SVG
  static String appLogo = 'assets/svg/app_logo.svg';
  static String settingIcon = 'assets/svg/setting.svg';
}
