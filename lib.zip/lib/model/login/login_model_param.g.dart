// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_model_param.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LoginModelParam _$LoginModelParamFromJson(Map<String, dynamic> json) =>
    LoginModelParam(
      username: json['username'] as String?,
      password: json['password'] as String?,
    );

Map<String, dynamic> _$LoginModelParamToJson(LoginModelParam instance) =>
    <String, dynamic>{
      'username': instance.username,
      'password': instance.password,
    };
