enum ApiMethod { post, get, put, delete, patch }
