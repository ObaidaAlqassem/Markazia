class ServiceMenuModel {
  final int serviceMenuId;
  final String serviceMenuTitle;

  ServiceMenuModel({
    required this.serviceMenuId,
    required this.serviceMenuTitle,
  });
}
